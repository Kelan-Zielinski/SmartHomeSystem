#ifndef HOUSE_H_
#define HOUSE_H_
#include "room.h"
using namespace std;

class house {
private:
	int  id; //house id
	string name; //house name
	string address1; //house address line 1
	string address2; //house address line 2
	string loginname; //loginname
	string password; //password
	Vec<room> rooms; // room vector
	int next_room_id;
	int next_light_id; 
	int next_blind_id; 

public:
	house();//constructor
	house(int, string, string, string);//constructor with parameters
	void addRoom();//add a room to house function
	void menu_home();//menu method

//getters
	int getHouseID();
	string getHouseName();
	string getHouseAdd1();
	string getHouseAdd2();
	int getNextRoomID();
	int getNextLightID();
	int getNextBlindID();

	ostream& room_menu(ostream&);//print function
	ostream& print_house(ostream&);//print function
};

#endif
