#include "blinds.h"

//contruct

blind::blind() {
	id=0;
	name = " ";
	open = 0;
	close = 1;
	raise = 0;
	lower = 1;
	ocState = false;
	rlState = false;
}

blind::blind(int i, string n){
	id=i;
	name=n;
	open = 0;
	close = 1;
	raise  = 0;
	lower =1;
    ocState = false;
    rlState = false;
}

//setters
void blind::setId(int i){
	id=i;
}

void blind::setName(string l){
	name=l;
}

void blind::setBlind(char u) {
	if (u=='o'){
		open=1;
		ocState=true;
		close =0;
	}

	else if (u=='c'){
		close=1;
		open=0;
		ocState=false;
		raise=0;
		lower=1;
		rlState=false;
	}

	else if (u=='r'){
		ocState=true;
		raise=1;
		lower=0;
		rlState=true;
		open=1;
		close=0;
	}

	else if (u=='l'){
		lower=1;
		rlState=false;
		raise=0;
	}
}

//getters

int blind::getId() {
	return id;
}

string blind::getName() {
	return name;
}

bool blind::blindOpenState() {
	return ocState;
}

bool blind::blindraiseState() {
	return rlState;
}
