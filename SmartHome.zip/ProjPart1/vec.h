#include "hw.h"

using namespace std;

template<class A>
class Vec {
private:
	A *_data;
	int _size;
	int _max;

	void _init();
	void _clear();
	void _create();
	int _resize(int);

public:
	Vec();	// default constructor
    A& at(int);
    
	int addValue(A);
	A removeValue();

	int getSize() { return _size; }
	bool isEmpty();
	bool isFull();

	ostream& print(ostream&);

};

template<class A>
A& Vec<A>::at(int i){ // .at() implementation
    return _data[i];
}

template<class A>
Vec<A>::Vec() {
	_init();
}

template<class A>
void Vec<A>::_init() {
	_data = NULL;
	_size = 0;
	_max = _size;
}

template<class A>
void Vec<A>::_clear() {
	if (!isEmpty()) {
		delete[] _data;
	}
	_init();
}

template<class A>
void Vec<A>::_create() {
	_clear();
	_max = 1;
	_data = new A[_max];
}

template<class A>
int Vec<A>::_resize(int inc) {
	if (isEmpty()) {
		_create();
	} else {
		_max = _max + inc;
		A *newData = new A[_max];
		int numVals = _size;
		if (inc<0) numVals = numVals + inc;
		_size = numVals;
		for(int i=0;i<numVals;i++) newData[i] = _data[i]; // *(newData+i) = *(_data+i
		delete[] _data;
		_data = newData;
	}
	return _max;
}

template<class A>
bool Vec<A>::isEmpty() {
	if (_size==0) return true;
	else return false;
}

template<class A>
bool Vec<A>::isFull() {
	if (_size==_max) return true;
	else return false;
}

template<class A>
int Vec<A>::addValue(A val) {
	if (_data==NULL) {
		_create();
		_data[_size] = val;
		_size++;
	} else if (isFull()) {
		_max = _resize(1);
		_data[_size] = val;
		_size++;
	} else {
		_data[_size] = val;
		_size++;
	}
	return _max;
}

template<class A>
A Vec<A>::removeValue() {
	A val;
	if (!isEmpty()) {
		val = _data[_size-1];
		_max = _resize(-1);
	}
	return val;
}

template<class A>
ostream& Vec<A>::print(ostream &out) {

	if (_data==NULL) out << "Vector not created\n";
	else if (isEmpty()) out << "Vector is empty\n";
	else {
		for(int i=0;i<_size;i++) {
			out << "data[" << i << "] = " << _data[i] << endl;
		}
	}
	return out;
}
