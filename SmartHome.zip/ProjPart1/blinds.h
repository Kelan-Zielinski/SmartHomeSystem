#ifndef BLIND_H
#define BLIND_H
#include "light.h"

using namespace std;

class blind {

private:
	int id;
	string name;
	bool ocState; 
    bool rlState;

public:
	int open;
    int close; 
    int raise; 
    int lower;

	//construct
	blind();
	blind(int,string);

	//setters
	void setId(int);
	void setName(string);
	void setBlind(char);

	//getters
	int getId();
	string getName();
	bool blindOpenState();
	bool blindraiseState();
};

#endif
