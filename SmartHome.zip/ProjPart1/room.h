#ifndef ROOM_H_
#define ROOM_H_
#include "blinds.h"

using namespace std;
class room {
private:
	int id; //room id
	string name; //room name
	string location; //room location
	int Numlights;
	Vec<light> lights; //vector of lights
	int NumBlinds; //number of blinds
	Vec<blind> blinds; //vector of blinds

public:
	room();//contructor
	room(int&, string, string);//constructor with parameters
	void room_menu(int&,int&);//menu
	void addLight(int&);//light
	void addBlind(int&);//blind

//setters
	//rooms
	void setRoomID(int);
	void setRoomName(string);
	void setRoomLocation(string);
	//lights
	void setLightState(int,bool);
	void setNumLights(int);
	//blinds
	void setNumBlinds(int);
	void setBlind(int,char);

//getters
	//room
	int getRoomID();
	string getRoomname();
	string getRoomlocation();

	//blinds
	int getBlindID(int);
	string getBlindLocation(int);
	string getOCState(int);
	string getRLState(int);
	int getNumBlinds();

	//lights
	int getLightId(int);
	string getLightName(int);
	string getLightState(int);
	int getNumLights();

	ostream& lightoverload(ostream&);//print
	ostream& blindoverload(ostream&);//print
	ostream& printRoom(ostream&);//print
};

#endif
