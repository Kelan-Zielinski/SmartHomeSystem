#ifndef LIGHT_H_
#define LIGHT_H_
#include "vec.h"
using namespace std;

class light {
private:
	int id;
	string name;
	bool state;
public:
	//constructor
	light();
	light(int, string);

	//setters
	void setId(int);
	void setName(string);
	void setState(bool);

	//getters
	int getId();
	bool getState();
	string getName();
};

#endif
