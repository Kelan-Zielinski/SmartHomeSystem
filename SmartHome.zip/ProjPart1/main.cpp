#include <fstream>
#include "house.h"

int main() {

	house house1 = house(5000,"My House","123 Main Street","Anytown, FL. 33146");
	house1.menu_home();
}