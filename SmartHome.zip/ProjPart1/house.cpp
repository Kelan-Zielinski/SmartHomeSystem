#include "house.h"

//constructor: initiallizing the values for the attributes of house
house::house(){
	id = -1;
	name = "";
	address1 = "";
	address2="";
	loginname="username";
	password="password";
	next_room_id =-1;
	next_light_id =-1;
	next_blind_id =-1;
}
//setting the inputted values for the attributes of house
house::house(int i, string n, string a1, string a2){
	id = i;
	name = n;
	address1 = a1;
	address2 = a2;
	loginname="username";
	password="password";
	next_room_id  = 100;
	next_light_id = 200;
	next_blind_id  = 300;
}

//implementation of our house menu

void house::menu_home(){
    do {
        cout << "Main Menu:"<<endl;
        cout<<"House: "<<id<<endl;
        cout<<address1<<endl;
        cout<<address2<<endl;
        
        cout<<"1.  Show status all"<<endl;
        cout<<"2.  Room menu"<<endl;
        cout<<"3.  Add Room"<<endl;
        cout<<"99. Exit"<<endl<<endl;
        cout<<"Enter a number: "<<endl;
        
        int input;
        cin >> input;
		if(cin.fail()){
			cin.clear();
			cout<<"INVALID SELECTION"<<endl;
		}
		else if(input==99){break;}
		else if(input==97){
			if(!rooms.isEmpty()){
				rooms.removeValue();
				next_room_id --;}
		}
		else if(input==1){print_house(cout);
		}
		else if(input==2){
			if(!rooms.isEmpty()){
			cout<<"List of rooms: "<<endl;
			room_menu(cout);
			cout<<"Which room would you like? ";
			cin>>input;
			rooms.at(input-1).room_menu(next_light_id, next_blind_id);
			}
			else{
			cout<<endl<<"There are no rooms created"<<endl;
			}
		}
		else if(input==3){
			addRoom();
		}
		else{
			input=0;
		}
	}while(true);
}

void  house::addRoom(){
	string n;
	string l;
	int room_index = next_room_id -99;
                //room menu add
                id=next_room_id ;
                cout<<"Enter room name: ";
                getline(cin >> ws, n);
		cout<<"Enter the location of "<<n<<": ";
		getline(cin >> ws, l);
		room temp;
		temp = room(next_room_id ,n,l);
		rooms.addValue(temp);
}

//getters
int house::getHouseID(){
	return id;
}
string house::getHouseName(){
	return name;
}
string house::getHouseAdd1(){
	return address1;
}
string house::getHouseAdd2(){
	return address2;
}
int house::getNextRoomID (){
	return next_room_id ;
}
int house::getNextLightID(){
	return next_light_id;
}
int house::getNextBlindID(){
	return next_blind_id ;
}
 //printer 
ostream& house::room_menu(ostream &out){
        int room_number = next_room_id -100;
        for(int i=0;i< room_number ;i++){
                out<<i+1<<". "<<rooms.at(i).getRoomname();
        }out<<"\n";  return out;
}

ostream& house::print_house(ostream &out){
	if(rooms.isEmpty()){
				cout<<"\nNo more rooms created. ";
	}
	else{
		int room_number = next_room_id -100;
		for(int i=0;i<room_number;i++){
			out<<"\n";
			rooms.at(i).printRoom(cout);
		}
	}
	return out;
}
ostream& operator<<(ostream &out, house &h){
	h.print_house(out);
	return out;
}
